import { useState, useEffect } from "react";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Home, Car, Briefcase, ArrowRight, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

// Tipos de Consórcio e Regras de Negócio
type ConsortiumType = "imovel" | "veiculo" | "servico";

interface ConsortiumRules {
  minCredit: number;
  maxCredit: number;
  minTerm: number;
  maxTerm: number;
  adminRate: number; // Taxa total
  reserveFund: number; // Taxa total
  hasReducedInstallment: boolean;
  hasEmbeddedBid: boolean;
}

const RULES: Record<ConsortiumType, ConsortiumRules> = {
  imovel: {
    minCredit: 80000,
    maxCredit: 1000000,
    minTerm: 160,
    maxTerm: 240,
    adminRate: 0.242,
    reserveFund: 0,
    hasReducedInstallment: true,
    hasEmbeddedBid: false
  },
  veiculo: {
    minCredit: 15000,
    maxCredit: 1000000,
    minTerm: 24,
    maxTerm: 90,
    adminRate: 0.152,
    reserveFund: 0.01,
    hasReducedInstallment: false,
    hasEmbeddedBid: true
  },
  servico: {
    minCredit: 15000,
    maxCredit: 50000,
    minTerm: 20,
    maxTerm: 50,
    adminRate: 0.15,
    reserveFund: 0.01,
    hasReducedInstallment: false,
    hasEmbeddedBid: false
  }
};

export function ConsortiumCalculator() {
  const [type, setType] = useState<ConsortiumType>("imovel");
  const [creditValue, setCreditValue] = useState<number>(300000);
  const [term, setTerm] = useState<number>(240);

  // Atualizar valores padrão ao mudar de tipo
  useEffect(() => {
    const rule = RULES[type];
    if (creditValue < rule.minCredit) setCreditValue(rule.minCredit);
    if (creditValue > rule.maxCredit) setCreditValue(rule.maxCredit);
    setTerm(rule.maxTerm);
  }, [type]);

  const rule = RULES[type];

  // Cálculos
  const totalRate = rule.adminRate + rule.reserveFund;
  const totalAmount = creditValue * (1 + totalRate);
  const fullInstallment = totalAmount / term;
  const reducedInstallment = rule.hasReducedInstallment ? fullInstallment * 0.7 : null;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const handleSimulate = () => {
    const message = `Olá Erik! Fiz uma simulação no site:%0A%0A` +
      `🏠 *Categoria:* ${type.toUpperCase()}%0A` +
      `💰 *Crédito:* ${formatCurrency(creditValue)}%0A` +
      `📅 *Prazo:* ${term} meses%0A` +
      `📊 *Parcela:* ${formatCurrency(fullInstallment)}%0A` +
      `${reducedInstallment ? `📉 *Parcela Reduzida:* ${formatCurrency(reducedInstallment)}%0A` : ''}` +
      `%0AQuero saber mais detalhes!`;
    
    window.open(`https://wa.me/5547920024978?text=${message}`, '_blank');
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-black/80 backdrop-blur-xl border border-[#D4AF37]/30 shadow-[0_0_50px_rgba(0,0,0,0.8)] relative overflow-hidden group rounded-2xl">
      {/* Efeito de brilho dourado no fundo */}
      <div className="absolute -top-32 -right-32 w-64 h-64 bg-[#D4AF37]/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute -bottom-32 -left-32 w-64 h-64 bg-[#D4AF37]/5 rounded-full blur-[100px] pointer-events-none"></div>
      
      <CardHeader className="pb-6 relative z-10 border-b border-[#D4AF37]/10">
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#D4AF37]/50 to-transparent"></div>
        <CardTitle className="text-2xl font-heading text-center text-gold-metallic tracking-wide">
          Simulação
        </CardTitle>
        <p className="text-center text-gray-400 text-xs uppercase tracking-[0.2em] font-light mt-2">
          Selecione sua próxima conquista
        </p>
      </CardHeader>

      <CardContent className="space-y-8 pt-8 relative z-10">
        {/* Seleção de Categoria */}
        <Tabs defaultValue="imovel" value={type} onValueChange={(v) => setType(v as ConsortiumType)} className="w-full">
          <TabsList className="grid grid-cols-3 w-full bg-black/50 border border-[#D4AF37]/20 p-1 rounded-xl">
            <TabsTrigger value="imovel" className="data-[state=active]:bg-gold-metallic data-[state=active]:text-black font-bold transition-all duration-500 rounded-lg text-gray-400">
              <Home className="w-4 h-4 mr-2" /> Imóvel
            </TabsTrigger>
            <TabsTrigger value="veiculo" className="data-[state=active]:bg-gold-metallic data-[state=active]:text-black font-bold transition-all duration-500 rounded-lg text-gray-400">
              <Car className="w-4 h-4 mr-2" /> Veículo
            </TabsTrigger>
            <TabsTrigger value="servico" className="data-[state=active]:bg-gold-metallic data-[state=active]:text-black font-bold transition-all duration-500 rounded-lg text-gray-400">
              <Briefcase className="w-4 h-4 mr-2" /> Serviço
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Slider de Valor do Crédito */}
        <div className="space-y-4">
          <div className="flex justify-between items-end">
            <label className="text-xs uppercase tracking-widest text-[#D4AF37]">Valor do Crédito</label>
            <span className="text-2xl font-bold font-mono text-white drop-shadow-[0_0_10px_rgba(212,175,55,0.3)]">
              {formatCurrency(creditValue)}
            </span>
          </div>
          <Slider
            value={[creditValue]}
            min={rule.minCredit}
            max={rule.maxCredit}
            step={1000}
            onValueChange={(vals) => setCreditValue(vals[0])}
            className="py-4 cursor-grab active:cursor-grabbing"
          />
          <div className="flex justify-between text-[10px] text-gray-500 uppercase tracking-wider">
            <span>{formatCurrency(rule.minCredit)}</span>
            <span>{formatCurrency(rule.maxCredit)}</span>
          </div>
        </div>

        {/* Slider de Prazo */}
        <div className="space-y-4">
          <div className="flex justify-between items-end">
            <label className="text-xs uppercase tracking-widest text-[#D4AF37]">Prazo de Pagamento</label>
            <span className="text-2xl font-bold font-mono text-white drop-shadow-[0_0_10px_rgba(212,175,55,0.3)]">
              {term} <span className="text-sm font-normal text-gray-400">meses</span>
            </span>
          </div>
          <Slider
            value={[term]}
            min={rule.minTerm}
            max={rule.maxTerm}
            step={1}
            onValueChange={(vals) => setTerm(vals[0])}
            className="py-4 cursor-grab active:cursor-grabbing"
          />
          <div className="flex justify-between text-[10px] text-gray-500 uppercase tracking-wider">
            <span>{rule.minTerm} meses</span>
            <span>{rule.maxTerm} meses</span>
          </div>
        </div>

        {/* Resultados da Simulação */}
        <div className="bg-gradient-to-b from-[#1a1a1a] to-black rounded-xl p-6 border border-[#D4AF37]/20 space-y-4 shadow-inner relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#D4AF37]/30 to-transparent"></div>
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 md:gap-4">
            <span className="text-sm text-gray-400 uppercase tracking-wider">Parcela Mensal</span>
            <span className="text-xl md:text-2xl font-bold font-mono text-gold-metallic break-all text-right w-full md:w-auto">
              {formatCurrency(fullInstallment)}
            </span>
          </div>


        </div>

        {/* Benefícios Específicos */}
        <div className="space-y-2 pl-2 border-l-2 border-[#D4AF37]/30">
          {rule.hasEmbeddedBid && (
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <CheckCircle2 className="w-3 h-3 text-[#D4AF37]" />
              <span>Lance Embutido disponível (até 30%)</span>
            </div>
          )}
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <CheckCircle2 className="w-3 h-3 text-[#D4AF37]" />
            <span>Sem juros, apenas taxa administrativa fixa</span>
          </div>
        </div>

        <Button 
          onClick={handleSimulate}
          className="w-full bg-gold-metallic text-black font-bold text-lg h-14 shadow-[0_0_20px_rgba(212,175,55,0.3)] transition-all hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] rounded-xl uppercase tracking-widest"
        >
          Simular <ArrowRight className="ml-2 w-5 h-5" />
        </Button>
      </CardContent>
    </Card>
  );
}
