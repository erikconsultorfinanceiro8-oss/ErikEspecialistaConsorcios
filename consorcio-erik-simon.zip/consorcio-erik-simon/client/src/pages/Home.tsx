import { ConsortiumCalculator } from "@/components/ConsortiumCalculator";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  TrendingUp, 
  ShieldCheck, 
  Users, 
  DollarSign, 
  Award,
  Instagram,
  Mail,
  Phone,
  MapPin,
  Diamond
} from "lucide-react";

export default function Home() {
  const handleWhatsApp = () => {
    window.open("https://wa.me/5547920024978", "_blank");
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white overflow-x-hidden font-sans selection:bg-[#D4AF37] selection:text-black">
      
      {/* WhatsApp Flutuante Premium */}
      <button 
        onClick={handleWhatsApp}
        className="fixed bottom-8 right-8 z-50 bg-gradient-to-br from-[#25D366] to-[#128C7E] text-white p-4 rounded-full shadow-[0_0_30px_rgba(37,211,102,0.4)] transition-all hover:scale-110 hover:shadow-[0_0_50px_rgba(37,211,102,0.6)] animate-bounce-slow border border-white/10"
        aria-label="Fale no WhatsApp"
      >
        <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      </button>

      {/* HERO SECTION - MOBILE FIRST */}
      <section className="relative pt-8 pb-12 px-4 overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="/images/hero-bg-luxury.jpg" 
            alt="Luxury Background" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/90 to-[#050505]/60"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(212,175,55,0.15),transparent_50%)]"></div>
        </div>

        <div className="container relative z-10 space-y-10">
          {/* Apresentação Pessoal - Premium */}
          <div className="space-y-6 animate-fade-in-up max-w-3xl">
            <div className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#D4AF37]/40 bg-gradient-to-r from-[#D4AF37]/10 to-[#D4AF37]/5 backdrop-blur-md shadow-[0_0_30px_rgba(212,175,55,0.2)] hover:border-[#D4AF37]/60 transition-all">
              <Diamond className="w-4 h-4 text-[#D4AF37]" />
              <span className="text-[#D4AF37] font-semibold tracking-widest text-xs uppercase">Consultor Autorizado Ademicon</span>
            </div>
            
            <div className="space-y-3">
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-heading font-bold leading-tight text-white">
                Realize Seu <br/>
                <span className="text-gold-metallic drop-shadow-[0_0_40px_rgba(212,175,55,0.4)] inline-block">Sonho Financeiro</span>
              </h1>
              <div className="h-1 w-24 bg-gradient-to-r from-[#D4AF37] to-transparent rounded-full"></div>
            </div>
            
            <div className="space-y-4 pt-2">
              <div className="space-y-1">
                <p className="text-base md:text-lg text-gray-200 font-semibold">
                  <span className="text-[#D4AF37]">Erik Tatsch</span>
                </p>
                <p className="text-sm md:text-base text-gray-400 font-light">Especialista em Consórcios e Alavancagem Patrimonial</p>
              </div>

              <div className="space-y-3 pt-2 border-l-2 border-[#D4AF37]/40 pl-4">
                <p className="text-sm md:text-base text-gray-300 font-light leading-relaxed">
                  Meu time comercial já realizou mais de <span className="text-[#D4AF37] font-semibold">53 Milhões em Consórcios e Investimentos</span>.
                </p>
                <p className="text-sm md:text-base text-gray-300 font-light leading-relaxed">
                  Deixe-me ajudar você a conquistar seu sonho ou dobrar seu patrimônio com estratégias inteligentes e seguras.
                </p>
              </div>
            </div>
          </div>

          {/* CALCULADORA - DESTAQUE PRINCIPAL */}
          <div className="relative animate-fade-in-up delay-200">
            <ConsortiumCalculator />
          </div>

          {/* Números de Prova Social */}
          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="bg-[#0a0a0a]/80 backdrop-blur border border-[#D4AF37]/20 rounded-lg p-4 text-center">
              <h3 className="text-2xl md:text-3xl font-heading font-bold text-gold-metallic">+53 Mi</h3>
              <p className="text-xs md:text-sm text-gray-400 uppercase tracking-wider mt-2">Consórcios e Investimentos</p>
            </div>
            <div className="bg-[#0a0a0a]/80 backdrop-blur border border-[#D4AF37]/20 rounded-lg p-4 text-center">
              <h3 className="text-2xl md:text-3xl font-heading font-bold text-gold-metallic">100%</h3>
              <p className="text-xs md:text-sm text-gray-400 uppercase tracking-wider mt-2">Segurança</p>
            </div>
          </div>

          {/* Diferenciação - Especialista vs Vendedor */}
          <div className="bg-gradient-to-br from-[#0a0a0a] to-[#050505] border border-[#D4AF37]/30 rounded-xl p-6 md:p-8 space-y-4 shadow-[0_0_30px_rgba(212,175,55,0.1)]">
            <h3 className="text-lg md:text-xl font-heading font-bold text-white">
              <span className="text-[#D4AF37]">O Diferencial</span> de um Especialista em Consórcios
            </h3>
            
            <div className="space-y-3">
              <div className="flex gap-3">
                <div className="w-1 bg-gradient-to-b from-[#D4AF37] to-[#D4AF37]/30 rounded-full flex-shrink-0"></div>
                <div>
                  <p className="text-sm md:text-base text-gray-300 font-light leading-relaxed">
                    <span className="text-[#D4AF37] font-semibold">Estratégia Personalizada:</span> Não apenas vendo cotas, desenho um plano financeiro específico para suas necessidades e objetivos.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <div className="w-1 bg-gradient-to-b from-[#D4AF37] to-[#D4AF37]/30 rounded-full flex-shrink-0"></div>
                <div>
                  <p className="text-sm md:text-base text-gray-300 font-light leading-relaxed">
                    <span className="text-[#D4AF37] font-semibold">Acompanhamento Total:</span> Você não fica sozinho. Monitoro sua contemplação e ajusto a estratégia conforme necessário.
                  </p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <div className="w-1 bg-gradient-to-b from-[#D4AF37] to-[#D4AF37]/30 rounded-full flex-shrink-0"></div>
                <div>
                  <p className="text-sm md:text-base text-gray-300 font-light leading-relaxed">
                    <span className="text-[#D4AF37] font-semibold">Resultados Comprovados:</span> Mais de 53 milhões em consórcios e investimentos. É resultado de estratégia inteligente e alavancagem patrimonial bem executada.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Segurança */}
          <div className="flex items-center justify-center gap-2 text-gray-400 text-xs uppercase tracking-widest pt-4">
            <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
            <span>Banco Central do Brasil</span>
          </div>
        </div>
      </section>

      {/* SOBRE O ESPECIALISTA */}
      <section className="py-16 md:py-32 bg-[#050505] relative overflow-hidden">
        <div className="container grid md:grid-cols-2 gap-12 items-center">
          <div className="relative order-2 md:order-1 group">
            <div className="absolute inset-0 bg-gold-metallic opacity-20 translate-x-4 translate-y-4 rounded-sm blur-sm transition-all group-hover:translate-x-2 group-hover:translate-y-2"></div>
            <div className="absolute -inset-1 bg-gradient-to-br from-[#D4AF37] to-transparent opacity-30 rounded-sm"></div>
            <img 
              src="/images/erik-real.png" 
              alt="Erik Tatsch Simon" 
              className="relative rounded-sm shadow-2xl w-full max-w-md mx-auto border border-[#D4AF37]/20 grayscale hover:grayscale-0 transition-all duration-700 object-cover aspect-[3/4]"
            />
          </div>
          
          <div className="space-y-6 order-1 md:order-2">
            <div className="space-y-2">
              <h4 className="text-[#D4AF37] uppercase tracking-[0.3em] text-sm font-bold">O Especialista</h4>
              <h2 className="text-3xl md:text-5xl font-heading font-bold text-white">
                Erik Tatsch <span className="text-gold-metallic">Simon</span>
              </h2>
            </div>
            
            <p className="text-base md:text-lg text-gray-400 leading-relaxed font-light border-l border-[#D4AF37]/30 pl-6">
              Não vendo apenas consórcios; desenho estratégias de <strong className="text-white">alavancagem patrimonial</strong>. Meu time comercial já realizou mais de <strong className="text-[#D4AF37]">53 Milhões em Consórcios e Investimentos</strong>. Minha missão é provar matematicamente que o consórcio é a ferramenta mais sofisticada para quem busca multiplicar capital sem pagar juros abusivos.
            </p>

            <div className="space-y-4 pt-4">
              <div className="flex items-start gap-4">
                <TrendingUp className="w-6 h-6 text-[#D4AF37] flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-white font-bold mb-1">Alavancagem Inteligente</h4>
                  <p className="text-gray-400 text-sm">Multiplique seu capital com estratégias comprovadas e seguras.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <ShieldCheck className="w-6 h-6 text-[#D4AF37] flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-white font-bold mb-1">Segurança Regulada</h4>
                  <p className="text-gray-400 text-sm">Parceiro de uma administradora com mais de 30 anos de mercado, regulada pelo Banco Central.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Users className="w-6 h-6 text-[#D4AF37] flex-shrink-0 mt-1" />
                <div>
                  <h4 className="text-white font-bold mb-1">Consultoria Personalizada</h4>
                  <p className="text-gray-400 text-sm">Cada cliente é único. Desenho estratégias específicas para suas necessidades.</p>
                </div>
              </div>
            </div>

            <Button onClick={handleWhatsApp} className="w-full bg-gold-metallic text-black text-base px-8 py-6 rounded-xl font-bold shadow-[0_0_30px_rgba(212,175,55,0.3)] transition-all hover:scale-105 hover:shadow-[0_0_50px_rgba(212,175,55,0.5)] uppercase tracking-widest mt-6">
              Solicitar Consultoria
            </Button>
          </div>
        </div>
      </section>

      {/* INTELIGÊNCIA FINANCEIRA */}
      <section className="py-16 md:py-24 bg-[#0a0a0a] border-y border-[#D4AF37]/10 relative overflow-hidden">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-heading font-bold text-white mb-4">
              Inteligência <span className="text-gold-metallic">Financeira</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">Por que a alavancagem via consórcio é a escolha dos grandes investidores</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-[#050505] border-[#D4AF37]/20 hover:border-[#D4AF37]/50 transition-all">
              <CardContent className="p-6 space-y-4">
                <DollarSign className="w-8 h-8 text-[#D4AF37]" />
                <h3 className="text-xl font-bold text-white">Poder de Negociação à Vista</h3>
                <p className="text-gray-400 text-sm">Sua carta de crédito é dinheiro na mão. Negocie descontos agressivos na compra do seu imóvel ou veículo.</p>
              </CardContent>
            </Card>

            <Card className="bg-[#050505] border-[#D4AF37]/20 hover:border-[#D4AF37]/50 transition-all">
              <CardContent className="p-6 space-y-4">
                <ShieldCheck className="w-8 h-8 text-[#D4AF37]" />
                <h3 className="text-xl font-bold text-white">Blindagem Patrimonial</h3>
                <p className="text-gray-400 text-sm">Taxa administrativa de apenas 1,3% ao ano - uma das menores do mercado. Sem juros compostos.</p>
              </CardContent>
            </Card>

            <Card className="bg-[#050505] border-[#D4AF37]/20 hover:border-[#D4AF37]/50 transition-all">
              <CardContent className="p-6 space-y-4">
                <TrendingUp className="w-8 h-8 text-[#D4AF37]" />
                <h3 className="text-xl font-bold text-white">Custo Efetivo Racional</h3>
                <p className="text-gray-400 text-sm">Investimento regulado e fiscalizado pelo Banco Central do Brasil. Seu patrimônio protegido por lei.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section className="py-16 md:py-24 bg-[#050505] relative overflow-hidden">
        <div className="container">
          <h2 className="text-3xl md:text-5xl font-heading font-bold text-center text-white mb-16">
            Como <span className="text-gold-metallic">Funciona</span>
          </h2>

          <div className="grid md:grid-cols-4 gap-6">
            {[
              { num: "01", title: "Escolha o Bem", desc: "Imóvel, veículo ou serviço - você escolhe o que deseja adquirir." },
              { num: "02", title: "Simule o Plano", desc: "Use nossa calculadora para simular o melhor prazo e parcela para você." },
              { num: "03", title: "Desenhe a Estratégia", desc: "Juntos, estruturamos a melhor estratégia de alavancagem para seu perfil." },
              { num: "04", title: "Realize seu Sonho", desc: "Seja contemplado e adquira seu bem com segurança e inteligência." }
            ].map((step, idx) => (
              <div key={idx} className="relative group">
                <div className="bg-[#0a0a0a] border border-[#D4AF37]/20 rounded-lg p-6 h-full hover:border-[#D4AF37]/50 transition-all">
                  <div className="text-4xl md:text-5xl font-heading font-bold text-gold-metallic mb-4">{step.num}</div>
                  <h3 className="text-lg font-bold text-white mb-3">{step.title}</h3>
                  <p className="text-gray-400 text-sm">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24 bg-[#0a0a0a] border-t border-[#D4AF37]/10 relative overflow-hidden">
        <div className="container">
          <h2 className="text-3xl md:text-5xl font-heading font-bold text-center text-white mb-16">
            Perguntas <span className="text-gold-metallic">Frequentes</span>
          </h2>

          <div className="max-w-3xl mx-auto space-y-4">
            {[
              { q: "Qual é a diferença entre consórcio e financiamento?", a: "No consórcio, você paga uma taxa administrativa de apenas 1,3% ao ano. No financiamento, você paga juros compostos que podem chegar a 15-30% ao ano. A economia é significativa." },
              { q: "Quanto tempo leva para ser contemplado?", a: "Desenharemos uma estratégia a partir das suas necessidades e tentaremos o mais rápido possível para que você seja contemplado. Cada caso é único." },
              { q: "Posso usar o consórcio em leilões?", a: "Sim! Se você já tem um imóvel, pode usar o consórcio para comprar outro imóvel em leilão, aproveitando descontos agressivos." },
              { q: "É seguro? O Banco Central regula?", a: "Totalmente seguro. Somos parceiros de uma administradora regulada pelo Banco Central do Brasil há mais de 30 anos." }
            ].map((faq, idx) => (
              <details key={idx} className="group bg-[#050505] border border-[#D4AF37]/20 rounded-lg p-6 cursor-pointer hover:border-[#D4AF37]/50 transition-all">
                <summary className="flex items-start justify-between font-bold text-white">
                  {faq.q}
                  <span className="text-[#D4AF37] group-open:rotate-180 transition-transform">▼</span>
                </summary>
                <p className="text-gray-400 mt-4 text-sm">{faq.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-[#050505] via-[#0a0a0a] to-[#050505] relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.1),transparent_70%)]"></div>
        
        <div className="container relative z-10 text-center space-y-8 px-4">
          <h2 className="text-3xl md:text-5xl font-heading font-bold text-white">
            Seu próximo grande passo <br/>
            <span className="text-gold-metallic">começa com uma conversa</span>
          </h2>
          
          <p className="text-gray-400 max-w-2xl mx-auto text-base md:text-lg">
            Solicite sua análise de perfil gratuita e descubra como você pode multiplicar seu patrimônio com segurança.
          </p>

          <div className="flex justify-center">
            <Button onClick={handleWhatsApp} className="bg-gold-metallic text-black text-base md:text-lg px-8 md:px-12 py-6 md:py-7 rounded-xl font-bold shadow-[0_0_30px_rgba(212,175,55,0.3)] transition-all hover:scale-105 hover:shadow-[0_0_50px_rgba(212,175,55,0.5)] uppercase tracking-widest whitespace-nowrap">
              Solicitar Consultoria
            </Button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#000000] border-t border-[#D4AF37]/10 py-12 relative overflow-hidden">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div className="space-y-4">
              <h3 className="text-white font-bold text-lg">Erik Simon</h3>
              <p className="text-gray-400 text-sm">Especialista em Consórcios e Alavancagem Patrimonial</p>
              <p className="text-gray-500 text-xs">Consultor Autorizado Ademicon</p>
            </div>

            <div className="space-y-4">
              <h4 className="text-white font-bold">Contato</h4>
              <div className="space-y-2 text-sm">
                <a href="tel:+5547920024978" className="text-gray-400 hover:text-[#D4AF37] flex items-center gap-2 transition-colors">
                  <Phone className="w-4 h-4" />
                  (47) 92002-4978
                </a>
                <a href="mailto:Erik.consultorFinanceiro@gmail.com" className="text-gray-400 hover:text-[#D4AF37] flex items-center gap-2 transition-colors">
                  <Mail className="w-4 h-4" />
                  Erik.consultorFinanceiro@gmail.com
                </a>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-white font-bold">Redes Sociais</h4>
              <a href="https://instagram.com/Erik.Consultor.financeiro" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-[#D4AF37] flex items-center gap-2 transition-colors text-sm">
                <Instagram className="w-4 h-4" />
                @Erik.Consultor.financeiro
              </a>
            </div>
          </div>

          <div className="border-t border-[#D4AF37]/10 pt-8 text-center text-gray-500 text-xs">
            <p>© 2025 Erik Simon - Especialista em Consórcios. Todos os direitos reservados.</p>
            <p className="mt-2">Consultor Autorizado pela Ademicon - Administradora de Consórcios</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
