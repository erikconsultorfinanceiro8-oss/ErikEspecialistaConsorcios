# 🚀 Deploy no GitHub Pages - Erik Simon

## Instruções para Hospedar seu Site no GitHub

### Passo 1: Criar um Repositório no GitHub

1. Acesse [github.com](https://github.com) e faça login
2. Clique em **"New"** para criar um novo repositório
3. Nome do repositório: `consorcio-erik-simon` (ou outro nome de sua preferência)
4. Deixe como **Public** (para que o GitHub Pages funcione)
5. Clique em **"Create repository"**

### Passo 2: Preparar o Repositório Local

```bash
# Navegue até a pasta do projeto
cd /home/ubuntu/consorcio-erik-simon

# Inicialize o git (se ainda não estiver)
git init

# Adicione o repositório remoto (substitua USERNAME pelo seu usuário GitHub)
git remote add origin https://github.com/USERNAME/consorcio-erik-simon.git

# Configure sua identidade git
git config user.name "Seu Nome"
git config user.email "seu.email@example.com"

# Adicione todos os arquivos
git add .

# Faça o primeiro commit
git commit -m "Initial commit: Erik Simon - Especialista em Consórcios"

# Envie para o GitHub (branch main)
git branch -M main
git push -u origin main
```

### Passo 3: Configurar GitHub Pages

1. Acesse seu repositório no GitHub
2. Vá para **Settings** → **Pages**
3. Em "Source", selecione **Deploy from a branch**
4. Selecione a branch **gh-pages** (será criada automaticamente pelo workflow)
5. Clique em **Save**

### Passo 4: Configurar Domínio Personalizado (Opcional)

Se você tiver um domínio como `eriksimon.com.br`:

1. No arquivo `.github/workflows/deploy.yml`, já está configurado:
   ```yaml
   cname: eriksimon.com.br
   ```

2. Configure os registros DNS do seu domínio:
   - Adicione um registro **CNAME** apontando para `username.github.io`
   - Ou use registros **A** apontando para os IPs do GitHub Pages

3. Aguarde a propagação DNS (pode levar até 24 horas)

### Passo 5: Deploy Automático

O workflow está configurado para:
- ✅ Fazer build automático a cada push para `main`
- ✅ Deploy automático para GitHub Pages
- ✅ Usar cache para acelerar builds

**Basta fazer push e o site estará online em minutos!**

### Verificar o Deploy

1. Acesse seu repositório no GitHub
2. Clique em **Actions** para ver o histórico de deploys
3. Quando o workflow terminar com ✅, seu site estará em:
   - `https://username.github.io/consorcio-erik-simon` (sem domínio personalizado)
   - `https://eriksimon.com.br` (com domínio personalizado)

### Atualizar o Site

Para fazer alterações e atualizar o site:

```bash
# Faça suas alterações nos arquivos

# Adicione as mudanças
git add .

# Commit com mensagem descritiva
git commit -m "Atualizar seção de depoimentos"

# Envie para GitHub
git push
```

O deploy automático será acionado e seu site estará atualizado em minutos!

### Troubleshooting

**Problema:** O workflow falha com erro de build
- **Solução:** Verifique se `pnpm install` e `pnpm run build` funcionam localmente

**Problema:** O site não aparece após o deploy
- **Solução:** Aguarde 5-10 minutos e limpe o cache do navegador (Ctrl+Shift+Del)

**Problema:** Domínio personalizado não funciona
- **Solução:** Verifique os registros DNS e aguarde a propagação (até 24h)

---

**Dúvidas?** Consulte a [documentação oficial do GitHub Pages](https://docs.github.com/en/pages)
