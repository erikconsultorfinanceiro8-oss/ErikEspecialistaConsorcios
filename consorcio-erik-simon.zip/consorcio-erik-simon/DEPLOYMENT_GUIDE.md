# 📋 Guia Completo de Deployment - Erik Simon

## Opção 1: GitHub Pages (Recomendado - Gratuito)

### ✅ Vantagens
- Totalmente gratuito
- Deploy automático a cada push
- Suporta domínio personalizado
- SSL/HTTPS incluído
- Sem configurações complexas

### 📝 Passos Rápidos

1. **Crie um repositório no GitHub**
   ```
   https://github.com/new
   ```

2. **Clone o projeto e configure**
   ```bash
   cd /home/ubuntu/consorcio-erik-simon
   git init
   git remote add origin https://github.com/SEU_USUARIO/consorcio-erik-simon.git
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git push -u origin main
   ```

3. **Configure GitHub Pages**
   - Vá para Settings → Pages
   - Source: Deploy from a branch
   - Branch: gh-pages
   - Save

4. **Seu site estará em:**
   - `https://seu-usuario.github.io/consorcio-erik-simon`

### 🌐 Adicionar Domínio Personalizado

1. **Registre um domínio** (ex: eriksimon.com.br)

2. **Configure DNS** no seu registrador:
   ```
   CNAME: seu-usuario.github.io
   ```

3. **Adicione no GitHub:**
   - Settings → Pages → Custom domain
   - Digite: `eriksimon.com.br`
   - Save

4. **Aguarde propagação DNS** (até 24 horas)

---

## Opção 2: Vercel (Alternativa Simples)

### ✅ Vantagens
- Deploy em 1 clique
- Muito rápido
- Excelente performance
- Suporta domínio personalizado

### 📝 Passos

1. Acesse [vercel.com](https://vercel.com)
2. Clique em "Import Project"
3. Selecione seu repositório GitHub
4. Clique em "Deploy"
5. Seu site estará online em minutos

---

## Opção 3: Netlify (Alternativa Popular)

### ✅ Vantagens
- Interface amigável
- Deploy automático
- Formulários integrados
- Suporta domínio personalizado

### 📝 Passos

1. Acesse [netlify.com](https://netlify.com)
2. Clique em "New site from Git"
3. Selecione seu repositório GitHub
4. Build command: `pnpm run build`
5. Publish directory: `dist/public`
6. Deploy

---

## Opção 4: Seu Próprio Servidor (VPS)

### 📝 Passos (Ubuntu/Linux)

1. **Acesse seu servidor via SSH**
   ```bash
   ssh root@seu-ip
   ```

2. **Instale Node.js e pnpm**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
   sudo apt-get install -y nodejs
   npm install -g pnpm
   ```

3. **Clone o repositório**
   ```bash
   cd /var/www
   git clone https://github.com/seu-usuario/consorcio-erik-simon.git
   cd consorcio-erik-simon
   ```

4. **Instale dependências e faça build**
   ```bash
   pnpm install
   pnpm run build
   ```

5. **Configure Nginx**
   ```bash
   sudo nano /etc/nginx/sites-available/default
   ```
   
   Adicione:
   ```nginx
   server {
       listen 80;
       server_name eriksimon.com.br;
       
       root /var/www/consorcio-erik-simon/dist/public;
       index index.html;
       
       location / {
           try_files $uri $uri/ /index.html;
       }
   }
   ```

6. **Reinicie Nginx**
   ```bash
   sudo systemctl restart nginx
   ```

7. **Configure SSL com Certbot**
   ```bash
   sudo apt-get install certbot python3-certbot-nginx
   sudo certbot --nginx -d eriksimon.com.br
   ```

---

## 🔄 Fluxo de Atualização

Após escolher sua plataforma, para atualizar o site:

```bash
# Faça suas alterações
nano client/src/pages/Home.tsx

# Commit e push
git add .
git commit -m "Descrição da mudança"
git push origin main
```

**Pronto!** O site será atualizado automaticamente em minutos.

---

## 📊 Comparação de Plataformas

| Plataforma | Custo | Facilidade | Performance | Customização |
|-----------|-------|-----------|-------------|--------------|
| GitHub Pages | Grátis | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| Vercel | Grátis+ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| Netlify | Grátis+ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| VPS Próprio | Pago | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |

---

## 🎯 Recomendação

**Para começar: GitHub Pages**
- Totalmente gratuito
- Fácil de configurar
- Perfeito para sites estáticos
- Suporta domínio personalizado

**Se quiser mais recursos: Vercel ou Netlify**
- Melhor performance
- Mais funcionalidades
- Plano gratuito generoso

---

## ❓ Dúvidas Frequentes

**P: Posso usar meu próprio domínio?**
R: Sim! Todas as plataformas suportam domínios personalizados.

**P: Como faço para atualizar o site?**
R: Basta fazer `git push` e o deploy é automático.

**P: Quanto custa?**
R: GitHub Pages é totalmente gratuito. Vercel e Netlify têm planos gratuitos.

**P: Meu site será seguro (HTTPS)?**
R: Sim! Todas as plataformas incluem SSL/HTTPS.

---

**Pronto para colocar seu site no ar? Escolha uma opção acima e comece! 🚀**
